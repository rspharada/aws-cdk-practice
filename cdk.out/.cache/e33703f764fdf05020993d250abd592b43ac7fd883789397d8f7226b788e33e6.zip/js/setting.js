window.SETTING ={
    "product_id": "0fc83fa321817ef568b5ad1188f94daa",
    "log_key_id": ""
}